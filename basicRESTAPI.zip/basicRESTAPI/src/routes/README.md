📌 Fungsi:
Tempat mengatur daftar endpoint dan menghubungkannya ke controller.
