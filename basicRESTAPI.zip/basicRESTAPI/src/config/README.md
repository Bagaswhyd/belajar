📌 Fungsi:
Menyimpan file konfigurasi proyek, seperti koneksi database, environment variables, atau pengaturan global lainnya.